<?php


$languageStrings = array(
	'LBL_PARCIALIDADESFDI' => 'Parcialidades CFDI',
    'SINGLE_ParcialidadesCFDI' => 'Parcialidad CFDI',
    'LBL_PARCIALIDADESCFDI_INFORMATION' => 'Información Parcialidad CFDI'
);

$jsLanguageStrings = array();