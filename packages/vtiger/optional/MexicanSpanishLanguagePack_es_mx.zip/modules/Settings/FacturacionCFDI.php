<?php


$languageStrings = array(
	'cuenta' => 'Cuenta de Servicio de Timbrado',
    'emisor' => 'Datos del Emisor',
    'general' => 'Configuraciones Generales',
    'envio_cfdi' => 'Envío de CFDI (PDF y XML)',
    'recurrencia' => 'Timbrado automático de Facturas en estado "Automática"'
);

$jsLanguageStrings = array();
