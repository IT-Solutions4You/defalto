<?php


$languageStrings = array(
	'LBL_FACTURACIONCFDI' => 'Facturacion CFDI',
	'LBL_FACTURACIONCFDI_DESC' => 'Modulo para timbrado de facturas autorizadas por el SAT de acuerdo con leyes mexicanas',
	'LBL_NOMBRE_MODULO' => 'Facturacion CFDI',
	'LBL_INSTALAR' => 'Instalaci&oacute;n',
	'LBL_DESCARGA' => 'Descargar MPDF',
	"LBL_DESCARGA_SRC" => "Descargar MPDF",
	"LBL_DESCARGA_SRC_DESC" => 'Para generar facturas en formato PDF es necesario descargar la libreria MPDF. <br/>Si hay un error de descarga, descarga manualmente la libreria de http://simplesistemas.com/download/mpdf61.zip, descomprímela y cópiala a tu servidor en la ruta: [vtiger]/modules/FacturacionCFDI/libs/mpdf61, donde [vtiger] representa la raiz de instalacion de Vtiger.',
	"ERROR_DESCOMPRIMIR" => "No fue posible descromprimir manualmente la libreria mPDF.zip",
	"ERROR_DESCARGAR" => "Error al descargar la libreria mPDF de servidor remoto. Por favor asegurese de que su servidor tenga conexion a Internet.",
	"LBL_FIN" => "Fin",
	"LBL_INSTALACION_EXITOSA" => "Se ha completado correctamente la instalaci&oacute;n de Facturacion CFDI.",
	"LBL_ERROR_STRING" => "Se requiere el script de MPDF la extensi&oacute;n debe estar habilitada en su instalaci&oacute;n de PHP, por favor habilite esta extensi&oacutE;n para el correcto funcionamiento de Facturacion CFDI.",
	"LBL_TERMINOS_CONDICIONES" => "Terminos & Condiciones",
	"LBL_TERMINOS_CONDICIONES_STRING" => "Para hacer uso de la extensi&oacute;n, usted acepta que sus datos sean transferidos a un tercero autorizado por el SAT, con el unico objetivo de Timbrar o Cancelar sus facturas.<br>
										El usuario es responsable de verificar el correcto timbrado o cancelacion de timbrado ante el SAT y excime de toda responsabilidad a Simple (Sistemas E Implementos Empresariales SA de CV) ante errores de timbrado o cancelacion de timbrado al utilizar este software.",
	"LBL_INSTALACION_SIN_TERMINAR" => "Concluir instalacion",
	"LBL_ACEPTAR_DESCARGA" => "Acepto",
	
	"LBL_CHECK_SERVER_SETTINGS" => "Checar requerimientos nuevamente",
	"LBL_SERVER_REQUIREMENTS" => "Requisitos del Servidor",
	"LBL_SERVER_REQUIREMENTS_DESCRIPTION" => "El correcto funcionamiento de <b>Facturacion CFDI</b> requiere la presencia de ciertos módulos y valores mínimos en algunas variables de PHP en tu servidor de Vtiger.<br> Si no se cumplen los requerimientos, <b>Facturacion CFDI</b> no funcionará correctamente.",
);

$jsLanguageStrings = array();
